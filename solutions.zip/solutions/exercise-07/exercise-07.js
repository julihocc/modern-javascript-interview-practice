const arr = [0,1,2,3]

const max = arr => Math.max(...arr)

console.log(max(arr))


